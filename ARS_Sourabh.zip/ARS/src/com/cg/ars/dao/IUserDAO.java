package com.cg.ars.dao;

import com.cg.ars.exception.ARSException;


public interface IUserDAO {
	public String verifyUser(String userName,String password,String role) throws ARSException;
	
}
