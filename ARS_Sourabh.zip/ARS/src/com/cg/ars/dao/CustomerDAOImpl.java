package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;
import com.cg.ars.util.DBConnection;

public class CustomerDAOImpl implements ICustomerDAO {			
	
	
	@Override
	public List<FlightInformationBean> viewFlights(String source,
			String destination) throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperCustomer.VIEW_FLIGHTS);) {
			
		} catch (Exception e) {
			// TODO: handle exception
		}

		return null;
		
	}

	@Override
	public BookingInformationBean makeReservation(String flightNumber,
			String customerEmail, int numberOfPassengers, String classType,
			String creditCardInformation) throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperCustomer.MAKE_RESERVATION);) {
				
			} catch (Exception e) {
				// TODO: handle exception
			}

			return null;
			
	}

	@Override
	public BookingInformationBean viewReservation(String bookingId)
			throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperCustomer.VIEW_RESERVATION);) {
				
			} catch (Exception e) {
				// TODO: handle exception
			}

			return null;
			
	}

	@Override
	public boolean cancelReservation(String bookingId) throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperCustomer.CANCEL_RESERVATION);) {
				
			} catch (Exception e) {
				// TODO: handle exception
			}

			return false;
			
	}

	@Override
	public BookingInformationBean updateReservation(String bookingId,
			String classType, String numberOfPassengers) throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperCustomer.UPDATE_RESERVATION);) {
				
			} catch (Exception e) {
				// TODO: handle exception
			}

			return null;
			
	}

}
