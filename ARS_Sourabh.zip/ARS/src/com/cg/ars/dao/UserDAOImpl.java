package com.cg.ars.dao;

import com.cg.ars.exception.ARSException;

public class UserDAOImpl implements IUserDAO {

	@Override
	public String verifyUser(String userName, String password, String role)
			throws ARSException {
		// TODO Auto-generated method stub
		return null;
	}

		
	//Don't implement this method implement above method
	
	
/* WRONG METHOD IMPLEMENTED
	@Override
	public String verifyUser(String userName,String password,String role) throws ARSException {

		String user = null;
		try(Connection connPurchaseDetails =DBConnection.getInstance().getConnection();
				PreparedStatement preparedStatement=
				connPurchaseDetails.prepareStatement(QueryMapper.VALID_USER);
				){
				preparedStatement.setString(1, userName);
				preparedStatement.setString(2, password);
				preparedStatement.setString(3, role);
				
				
				ResultSet resultset=preparedStatement.executeQuery();
				while (resultset.next()) {
					
				user=resultset.getString(1);
					
				}
			
		}catch(SQLException sqlEx){
			throw new ARSException(sqlEx.getMessage());
		}
		
		return user;
	}*/
}


