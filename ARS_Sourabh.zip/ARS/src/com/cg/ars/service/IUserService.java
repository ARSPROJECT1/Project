package com.cg.ars.service;


import com.cg.ars.exception.ARSException;

public interface IUserService {
	public String verifyUser(String userName,String password,String role) throws ARSException;
	
}
