/**
 * 
 */
package com.cg.service;

import com.cg.ars.exception.ARSException;

/**
 * @author CAPG
 *
 */
public interface IUserService {

	public boolean isValidUser(String userName, String password, String role)
			throws ARSException;

	public boolean isValidUserName(String userName) throws ARSException;

	public boolean isValidPassword(String password) throws ARSException;

}
