package com.cg.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.ars.exception.ARSException;
import com.cg.service.FlightInfoServiceImpl;
import com.cg.service.IFlightInfoService;

public class TestViewFlights {
	
	static IFlightInfoService fservice=null;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		fservice=new FlightInfoServiceImpl();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		fservice=null;
	}


	@Test
	public void testViewAllFlights() {
		try {
			assertNotNull(fservice.viewAllFlightInformation());
			
		} catch (ARSException e) {
			System.out.println("view Flights failed in junit"+e.getMessage());
		}
	}
	
	@Test
	public void testViewparticularFlight() {
		try {
			assertNotNull(fservice.viewParticularFlightInfo("22222"));
			
		} catch (ARSException e) {
			System.out.println("view particular flight failed in junit"+e.getMessage());
		}
	}
	
	@Test
	public void testViewUnavailableFlight() {
		try {
			assertNull(fservice.viewParticularFlightInfo("00000"));
			
		} catch (ARSException e) {
			System.out.println("view particular flight failed in junit"+e.getMessage());
		}
	}

}
