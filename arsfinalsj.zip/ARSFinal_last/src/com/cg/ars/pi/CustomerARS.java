package com.cg.ars.pi;

import java.util.List;
import java.util.Scanner;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;
import com.cg.service.BookingInfoServiceImpl;
import com.cg.service.FlightInfoServiceImpl;
import com.cg.service.IBookingInfoService;
import com.cg.service.IFlightInfoService;




public class CustomerARS {
	

	static Scanner ip = new Scanner(System.in);
	
	/*******************************************************************************************************
	 * - Function Name : confirmBooking() 
	 * - Return Type   : void 
	 * - Author        : ARS Team 
	 * - Creation Date : 14/12/2017 
	 * - Description   : Booking A Ticket
	 ********************************************************************************************************/

	public void confirmBooking() {
		System.out.println("Please enter key to continue");
		ip.nextLine();
		
		BookingInformationBean bean = new BookingInformationBean();
		IBookingInfoService bookinginfoservice = new BookingInfoServiceImpl();
		IFlightInfoService flightInfoService = new FlightInfoServiceImpl();
		FlightInformationBean fbean = null;
		String flightNo = null;

		System.out
				.println("Please enter source and destination to view flights");
		
		/**
		 * Validating sourceCity
		 */
		System.out.println("PLease enter source city");
		String sourceCity = null;
		boolean isValid=false;
		while(!isValid)
		{
		try {
			sourceCity=ip.nextLine();
			isValid= bookinginfoservice.isValidSourceCity(sourceCity);
		
		} catch (ARSException e) {
		
			//logger.error("Invalid source city: "+sourceCity);
			System.err.println("Invalid source city" +sourceCity);
			System.out.println("Please enter again. . .");
			isValid=false;
		}
		}
		
		/**
		 * 
		 */
		
		
		
		/**
		 * Validating destinationCity
		 */
		
		
		System.out.println("PLease enter destination city");
		String destinationCity = null;
		isValid=false;
		while(!isValid)
		{
		try {
			destinationCity=ip.nextLine();
			isValid= bookinginfoservice.isValidDestinationCity(destinationCity);
		} catch (ARSException e2) {
			//logger.error("Invalid destinationCity: "+destinationCity);
			System.err.println("Invalid destinationCity" +destinationCity);
			System.out.println("Please enter again. . .");
			isValid=false;
		}
		}
		
		
		
		/**
		 * 
		 */
		
		
		try {

			List<FlightInformationBean> list = bookinginfoservice.viewFlights(
					sourceCity, destinationCity);

			for (FlightInformationBean flightInformationBean : list) {

				System.out.println(flightInformationBean);
			}

			/**
			 * Validating flightNo
			 */
			
			
			
			System.out.println("Enter flight number to book flight");
			flightNo = null;
			isValid=false;
			while(!isValid)
			{
			try {
				flightNo=ip.nextLine();
				isValid= bookinginfoservice.isValidFlightNumber(flightNo);
			} catch (ARSException e2) {
				//logger.error("Invalid flightNo: "+flightNo);
				System.err.println("Invalid flightNo" +flightNo);
				System.out.println("Please enter again. . .");
				isValid=false;
			}
			}
			
		
			
			/**
			 * 
			 */
			
			
			fbean = flightInfoService.viewParticularFlightInfo(flightNo);

		}

		catch (ARSException e1) {

			System.out.println("No flights Found");
			e1.printStackTrace();
		}

		System.out.println("Please enter below details");

		
		
		
		

		/**
		 * Validating emailId
		 */
		
		
		System.out.println("Enter customer Email");
		String emailId = null;
		isValid=false;
		while(!isValid)
		{
		try {
			emailId=ip.nextLine();
			bean.setCustomerEmail(emailId);
			isValid= bookinginfoservice.isValidMail(emailId);
		} catch (ARSException e2) {
			//logger.error("Invalid destinationCity: "+destinationCity);
			System.err.println("Invalid emailId" +emailId);
			System.out.println("Please enter again. . .");
			isValid=false;
		}
		}
		
		
		
		System.out.println("Enter Number of passenger");
		int noOfPassenger = 0;
		isValid=false;
		while(!isValid)
		{
		try {
			noOfPassenger=Integer.parseInt(ip.nextLine());
			bean.setNumberOfPassengers(noOfPassenger);
			isValid= bookinginfoservice.isValidMail(emailId);
		} catch (ARSException e2) {
			//logger.error("Invalid noOfPassenger: "+noOfPassenger);
			System.err.println("Invalid noOfPassenger" +noOfPassenger);
			System.out.println("Please enter again. . .");
			isValid=false;
		}
		}
		
		
	
		System.out.println("Enter Class Type");
		bean.setClassType(ip.nextLine());
		
		
		
		
		
		

		
		System.out.println("Enter credit Card Information");
		String creditInfo = null;
		isValid=false;
		while(!isValid)
		{
		try {
			creditInfo=ip.nextLine();
			bean.setCreditCardInformation(creditInfo);
			isValid= bookinginfoservice.isValidCreditInfo(creditInfo);
		} catch (ARSException e2) {
			//logger.error("Invalid creditInfo: "+creditInfo);
			System.err.println("Invalid creditInfo" +creditInfo);
			System.out.println("Please enter again. . .");
			isValid=false;
		}
		}
		
		bean.setFlightNumber(flightNo);
		String bookingId=null;
		try {
			//boolean isValid = bookinginfoservice.validateCustomer(bean,fbean);
			
			
				bookingId = bookinginfoservice.confirmBooking(bean, fbean);
			
			

			

			if (bookingId != null) {
				System.out.println("\nBooked successfully");
				System.out.println("Booking id is  " + bookingId);

			} else {
				System.out.println("failed");
			}
		} catch (ARSException e) {

			e.printStackTrace();
		}
	}

	
	/*******************************************************************************************************
	 * - Function Name : cancelBooking() 
	 * - Return Type   : void 
	 * - Author        : ARS Team 
	 * - Creation Date : 14/12/2017 
	 * - Description   : Cancel Booking
	 ********************************************************************************************************/
	
	public void cancelBooking() {

		System.out.println("Please enter key to continue");
		ip.nextLine();
		
		BookingInformationBean bean = new BookingInformationBean();
		IBookingInfoService bookinginfoservice = new BookingInfoServiceImpl();
		IFlightInfoService flightInfoService = new FlightInfoServiceImpl();

		System.out.println("Enter Booking Id");
		String bookingId = ip.nextLine();

		/**
		 * Validating Booking Id
		 */
		
		try {
			while(true)
			{
			if (bookinginfoservice.isValidBookingId(bookingId)) {
				break;
			} else {
				System.err
						.println("Please enter correct booking id, try again");
				bookingId = ip.nextLine();
			}
		} 
		}catch (ARSException e1) {
			System.out.println("validating booking id failed");
		}
		
		/**
		 * 
		 */
		
		
		try {
			bean = bookinginfoservice.displayBooking(bookingId);
			FlightInformationBean fbean = flightInfoService
					.viewParticularFlightInfo(bean.getFlightNumber());
		
			System.out.println(fbean);
			bookinginfoservice.cancelBooking(bookingId);
			bookinginfoservice.updateSeats(fbean, bean);

		} catch (ARSException e) {

			e.printStackTrace();
		}

	}
	
	
	
	/*******************************************************************************************************
	 * - Function Name : displayBooking() 
	 * - Return Type   : void 
	 * - Author        : ARS Team 
	 * - Creation Date : 14/12/2017 
	 * - Description   : Displays Flight information
	 ********************************************************************************************************/
	public void displayBooking() {

		System.out.println("Please enter key to continue");
		ip.nextLine();
		
		BookingInformationBean bean = new BookingInformationBean();
		IBookingInfoService bookinginfoservice = new BookingInfoServiceImpl();
		// IFlightInfoService flightInfoService= new FlightInfoServiceImpl();

		
		/**
		 * Validating Booking Id
		 */
		
		
		System.out.println("Enter Booking Id");
		String bookingId = null;

		boolean isValid=false;
		while(!isValid)
		{
		try {
			bookingId=ip.nextLine();
			isValid= bookinginfoservice.isValidBookingId(bookingId);
		} catch (ARSException e2) {
			//logger.error("Invalid bookingId: "+bookingId);
			System.err.println("Invalid bookingId" +bookingId);
			System.out.println("Please enter again. . .");
			isValid=false;
		}
		}
		
		
	
		/**
		 * 
		 */
		
		try {
			bean = bookinginfoservice.displayBooking(bookingId);
			
			System.out.println(bean);
		} catch (ARSException e) {
			System.out.println("Error inside dispalyBooking()");
			e.printStackTrace();
		}

	}

	
	
	/*******************************************************************************************************
	 * - Function Name : updateBooking() 
	 * - Return Type   : void 
	 * - Author        : ARS Team 
	 * - Creation Date : 14/12/2017 
	 * - Description   : Updates Flight information
	 ********************************************************************************************************/
	public void updateBooking() {

		System.out.println("Please enter key to continue");
		ip.nextLine();
		
		IBookingInfoService bookinginfoservice = new BookingInfoServiceImpl();

		System.out.println("Enter Booking Id");
		String bookingId = ip.nextLine();
		
		/**
		 * Validating Booking Id
		 */
		
	

		boolean isValid=false;
		while(!isValid)
		{
		try {
			bookingId=ip.nextLine();
			isValid= bookinginfoservice.isValidBookingId(bookingId);
		} catch (ARSException e2) {
			//logger.error("Invalid bookingId: "+bookingId);
			System.err.println("Invalid bookingId" +bookingId);
			System.out.println("Please enter again. . .");
			isValid=false;
		}
		}
		
		
		/**
		 * 
		 */

		try {
			BookingInformationBean bean = bookinginfoservice
					.displayBooking(bookingId);
			System.out.println(bean);
			
			
			/**
			 * Validating emailId
			 */
			
			
			System.out.println("Enter new customer Email");
			String emailId = null;
			isValid=false;
			while(!isValid)
			{
			try {
				emailId=ip.nextLine();
				bean.setCustomerEmail(emailId);
				isValid= bookinginfoservice.isValidMail(emailId);
			} catch (ARSException e2) {
				//logger.error("Invalid destinationCity: "+destinationCity);
				System.err.println("Invalid emailId" +emailId);
				System.out.println("Please enter again. . .");
				isValid=false;
			}
			}
		
			/**
			 * 
			 */
			

			bookinginfoservice.updateBooking(bookingId, emailId);

		} catch (ARSException e) {

			e.printStackTrace();
		}

	}
}
