package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;
import com.cg.ars.util.DBConnection;

public class CustomerDAOImpl implements ICustomerDAO {			
	
	
	@Override
	public List<FlightInformationBean> viewFlights(String source,
			String destination) throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperCustomer.VIEW_FLIGHTS);) {
			
		} catch (Exception e) {
			// TODO: handle exception
		}

		return null;
		
	}

	@Override
	public BookingInformationBean makeReservation(String flightNumber,
			String customerEmail, int numberOfPassengers, String classType,
			String creditCardInformation) throws ARSException {
		BookingInformationBean bookingInformationBean = new BookingInformationBean();
		FlightInformationBean fbean = new FlightInformationBean();
		
		try(Connection  conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperCustomer.MAKE_RESERVATION);
			PreparedStatement pst=conn.prepareStatement(IQueryMapperCustomer.VIEW_PARTICULAR_FLIGHT_INFORMATION);
				PreparedStatement prepSt=conn.prepareStatement(IQueryMapperCustomer.GET_BOOKING_ID);) {
			
			
			String seatNumbers=null;
			double totalFare=0;
			
			pst.setString(1, flightNumber);
			ResultSet particularFlightInformation = pst.executeQuery();
			if (particularFlightInformation.next()) {
				
				fbean.setFlightNumber(particularFlightInformation.getString("flightno"));
				fbean.setAirline(particularFlightInformation.getString("airline"));
				fbean.setDepartureCity(particularFlightInformation.getString("dep_city"));
				fbean.setArrivalCity(particularFlightInformation.getString("arr_city"));
				fbean.setDepartureDate(particularFlightInformation.getDate("dep_date").toLocalDate());
				fbean.setArrivalDate(particularFlightInformation.getDate("arr_date").toLocalDate());
				fbean.setDepartureTime(particularFlightInformation.getString("dep_time"));
				fbean.setArrivalTime(particularFlightInformation.getString("arr_time"));
				fbean.setFirstClassSeats(particularFlightInformation.getInt("FirstSeats"));
				fbean.setFirstClassSeatFare(particularFlightInformation.getDouble("FirstSeatFare"));
				fbean.setBussinessClassSeats(particularFlightInformation.getInt("BussSeats"));
				fbean.setBussinessClassSeatsFare(particularFlightInformation.getDouble("BussSeatsFare"));
			} else {
				return null;
			}
			

			
			if (classType.equalsIgnoreCase("firstclass")) {
				if (numberOfPassengers<fbean.getFirstClassSeats()) {
					PreparedStatement pstn = conn
							.prepareStatement(IQueryMapperCustomer.GET_FIRST_CLASS_SEAT_NUMBERS);
					
					fbean.setFirstClassSeats(fbean.getFirstClassSeats()-numberOfPassengers);
					//to-do add updateflightinfo() method
					for (int i = 0; i < numberOfPassengers; i++) {
						ResultSet rstFirstClass = pstn.executeQuery();
						seatNumbers += (" , "+rstFirstClass.toString());
					}
					totalFare = numberOfPassengers*fbean.getFirstClassSeatFare();
				}
				else{
					return null;
				}
				
			} else {
				if (numberOfPassengers<fbean.getBussinessClassSeats()) {
					PreparedStatement pstn = conn
							.prepareStatement(IQueryMapperCustomer.GET_BUSINESS_CLASS_SEAT_NUMBERS);
					fbean.setBussinessClassSeats(fbean.getBussinessClassSeats()-numberOfPassengers);
					//to-do add updateflightinfo() method
					for (int i = 0; i < numberOfPassengers; i++) {
						ResultSet rstBusinessClass = pstn.executeQuery();
						seatNumbers += (" , "+rstBusinessClass.toString());
					}
					totalFare = numberOfPassengers*fbean.getBussinessClassSeatsFare();
				}
				else{
					return null;
				}
			}
			
			
			
			ResultSet rs = prepSt.executeQuery();
			//bookingInformationBean.setBookingId(String.valueOf(rs.getInt(0)));
			
			bookingInformationBean.setBookingId(rs.toString());
			bookingInformationBean.setCustomerEmail(customerEmail);
			bookingInformationBean.setNumberOfPassengers(numberOfPassengers);
			bookingInformationBean.setClassType(classType);
			bookingInformationBean.setTotalFare(totalFare);
			bookingInformationBean.setSeatNumbers(seatNumbers);
			bookingInformationBean.setCreditCardInformation(creditCardInformation);
			bookingInformationBean.setSourceCity(fbean.getDepartureCity());
			bookingInformationBean.setDestinationCity(fbean.getArrivalCity());
			
			} catch (Exception e) {
				// TODO: handle exception
			}

			return bookingInformationBean;
			
	}

	@Override
	public BookingInformationBean viewReservation(String bookingId)
			throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperCustomer.VIEW_RESERVATION);) {
				
			} catch (Exception e) {
				// TODO: handle exception
			}

			return null;
			
	}

	@Override
	public boolean cancelReservation(String bookingId) throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperCustomer.CANCEL_RESERVATION);) {
				
			} catch (Exception e) {
				// TODO: handle exception
			}

			return false;
			
	}

	@Override
	public BookingInformationBean updateReservation(String bookingId,
			String classType, String numberOfPassengers) throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperCustomer.UPDATE_RESERVATION);) {
				
			} catch (Exception e) {
				// TODO: handle exception
			}

			return null;
			
	}

/*	@Override
	public FlightInformationBean viewParticularFlightInfo(String flightNumber)
			throws ARSException {
		try(Connection  conn = DBConnection.getInstance().getConnection();			
				PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperCustomer.VIEW_PARTICULAR_FLIGHT_INFORMATION);) {
				
			} catch (Exception e) {
				// TODO: handle exception
			}

			return null;
	}*/

}
