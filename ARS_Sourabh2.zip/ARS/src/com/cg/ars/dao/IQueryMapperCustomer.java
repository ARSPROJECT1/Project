package com.cg.ars.dao;

public interface IQueryMapperCustomer {

	public static final String VIEW_FLIGHTS ="SELECT flightno,airline,dep_city,arr_city, dep_date, arr_date, dep_time, arr_time, FirstSeats, FirstSeatFare, BussSeats, BussSeatsFare FROM flightinformation where src_city=? and dest_city=?";
	
	public static final String VIEW_RESERVATION ="SELECT booking_id, cust_email, no_of_passengers, class_type, total_fare, seat_number, CreditCard_info, src_city, dest_city FROM bookinginformation where booking_id=?";
	
	public static final String MAKE_RESERVATION ="INSERT INTO bookinginformation VALUES(?,?,?,?,?,?,?,?,?)";
	
	public static final String CANCEL_RESERVATION ="DELETE FROM bookinginformation WHERE booking_id=?";
	
	public static final String UPDATE_RESERVATION ="UPDATE bookinginformation SET no_of_passengers=?,class_type=?  where booking_id=?";
	
	public static final String VIEW_PARTICULAR_FLIGHT_INFORMATION ="SELECT flightno,airline,dep_city,arr_city, dep_date, arr_date, dep_time, arr_time, FirstSeats, FirstSeatFare, BussSeats, BussSeatsFare FROM flightinformation WHERE flightno=?";
	
	public static final String GET_BOOKING_ID ="SELECT bookingId_sequence.NEXTVAL FROM DUAL";
	
	public static final String GET_FIRST_CLASS_SEAT_NUMBERS ="SELECT seatNumbersFirstClass_sequence.NEXTVAL FROM DUAL";
	
	public static final String GET_BUSINESS_CLASS_SEAT_NUMBERS ="SELECT seatNumbersBusinessClass_sequence.NEXTVAL FROM DUAL";
	
	
	
/*public static final String VIEW_FLIGHTS ="SELECT flightno,airline,dep_city,arr_city, dep_date, arr_date, dep_time, arr_time, FirstSeats, FirstSeatFare, BussSeats, BussSeatsFare FROM flightinformation";
	
	public static final String VIEW_RESERVATION ="SELECT booking_id, cust_email, no_of_passengers, class_type, total_fare, seat_number, CreditCard_info, src_city, dest_city FROM bookinginformation where booking_id=?";
	
	public static final String MAKE_RESERVATION ="INSERT INTO bookinginformation VALUES(booking_id, cust_email, no_of_passengers, class_type, total_fare, seat_number, CreditCard_info, src_city, dest_city)";
	
	public static final String CANCEL_RESERVATION ="DELETE FROM bookinginformation WHERE booking_id=?";
	
	public static final String UPDATE_RESERVATION ="UPDATE bookinginformation SET no_of_passengers=?,class_type=?  where booking_id=?";*/
	

}
