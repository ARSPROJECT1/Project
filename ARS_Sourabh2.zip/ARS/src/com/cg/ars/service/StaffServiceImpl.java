package com.cg.ars.service;




import java.time.LocalDate;
import java.util.List;

import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.dao.IStaffDAO;
import com.cg.ars.dao.StaffDAOImpl;
import com.cg.ars.exception.ARSException;

public class StaffServiceImpl implements IStaffService {
	
	IStaffDAO staffDAO = new StaffDAOImpl();
	
	@Override
	public boolean verifyUser(String userName, String password, String role)
			throws ARSException {
		
		return staffDAO.verifyUser(userName, password, role);
	}

	@Override
	public List<FlightInformationBean> viewFlightInformation()
			throws ARSException {
		return staffDAO.viewFlightInformation();
	}

	@Override
	public FlightInformationBean viewParticularFlightInfo(String flightNumber)
			throws ARSException {
		return staffDAO.viewParticularFlightInfo(flightNumber);
	}

	@Override
	public boolean updateFlightInformation(FlightInformationBean flightInfoBean)
			throws ARSException {
		return staffDAO.updateFlightInformation(flightInfoBean);
	}

	@Override
	public List<FlightInformationBean> viewOverAllOccupancy(String sourceCity,
			String destinationCity) throws ARSException {
		return staffDAO.viewOverAllOccupancy(sourceCity, destinationCity);
	}

	@Override
	public int viewPeriodOccupancy(String flightNumber, LocalDate fromDate,
			LocalDate toDate) throws ARSException {
		return staffDAO.viewPeriodOccupancy(flightNumber, fromDate, toDate);
	}



	
/*	@Override
	public String validUser(String userName,String password,String role,String mobileNo) throws ARSException {
		IUserDAO userDAO = new UserDAOImpl() ;
		String user =userDAO.validuser(userName,password,role,mobileNo);
		return user;
	}*/
}