package com.cg.ars.pi;

import java.util.Scanner;

public class ARSMain {

	public static void main(String[] args) {
		Scanner ip = new Scanner(System.in);
		System.out.println("=====================================");
		System.out.println("WELCOME TO AIRLINE RESERVATION SYSTEM");
		System.out.println("SELECT THE USER TYPE TO LOGIN : ");
		System.out.println("1. CUTOMER LOGIN");
		System.out.println("2. STAFF LOGIN");
		Byte choice = Byte.parseByte(ip.next());
		if (choice==1) {
			System.out.println("Inside if");
		}
		else{
			System.out.println("Inside else");
		}
		
		ip.close();
	}

}
