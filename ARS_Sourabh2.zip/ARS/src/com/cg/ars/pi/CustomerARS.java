package com.cg.ars.pi;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;
import com.cg.ars.service.CustomerServiceImpl;
import com.cg.ars.service.ICustomerService;

public class CustomerARS {
 
	ICustomerService customerService=null;
	
	public CustomerARS() {
		super();
		customerService = new CustomerServiceImpl();
	}

	


 public void viewFlights()
 {	
	 Scanner ip =new Scanner(System.in);
	 System.out.println("To view flights enter source and destination city");	
	 System.out.println("Enter source city");
	 String source = ip.nextLine();
	 System.out.println("Enter destination city");
	 String destination = ip.nextLine();
	 try {
		List<FlightInformationBean> listFlights = customerService.viewFlights(source, destination);
		for(FlightInformationBean fbean:listFlights)
		{
			System.out.println(	fbean.getFlightNumber()+" "+
					fbean.getAirline()+
					fbean.getDepartureCity()+
					fbean.getArrivalCity()+
					fbean.getDepartureDate()+
					fbean.getArrivalDate()+
					fbean.getDepartureTime()+
					fbean.getArrivalTime()+
					fbean.getFirstClassSeats()+
					fbean.getFirstClassSeatFare()+
					fbean.getBussinessClassSeats()+			
					fbean.getBussinessClassSeatsFare());
		}
	} catch (ARSException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
			 
			 
	ip.close();		 
 }
 
 public void makeReservation()
 {
	 Scanner ip =new Scanner(System.in); 
	 String customerEmail=null;
	 int numberOfPassengers=0;
	 String classType=null;
	 String creditCardInformation=null;
	 
	 
	 ip.close();	
 }
 
 public void updateReservation()
 {
	 Scanner ip =new Scanner(System.in);
	 
	 ip.close();	
 }
 
 public void cancelReservation()
 {
	 Scanner ip =new Scanner(System.in);
	 
	 ip.close();	
 }
 
 

}
