package com.cg.ars.pi;

import java.util.Scanner;
import com.cg.ars.exception.ARSException;
import com.cg.service.IUserService;
import com.cg.service.UserServiceImpl;


public class ARSMain {

	/********************************************************************
	 * 
	 * Welcome page
	 *
	 * ******************************************************************/

	public static void main(String[] args) {

		StaffARS staff = new StaffARS();
		CustomerARS customer = new CustomerARS();
		Scanner ip = new Scanner(System.in);
		IUserService userService = new UserServiceImpl();

		System.out.println("=====================================");
		System.out.println("WELCOME TO AIRLINE RESERVATION SYSTEM");
		System.out.println("SELECT THE USER TYPE TO LOGIN : ");
		System.out.println("1. CUSTOMER LOGIN");
		System.out.println("2. STAFF LOGIN");
		Byte choice = Byte.parseByte(ip.next());

		/********************************************************************
		 * 
		 * Customer
		 *
		 * ******************************************************************/

		if (choice == 1) {

			System.out.println("\t\t WELOCOME ");
			while (true) {
				System.out.println("1--BOOK A TICKET");
				System.out.println("2--VIEW BOOKING DETAILS");
				System.out.println("3--UPDATE DETAILS");
				System.out.println("4--CANCEL RESERVATION");
				System.out.println("5--exit");

				int choice2 = ip.nextInt();

				switch (choice2) {

				case 1:
					customer.confirmBooking();
					break;
				case 2:
					customer.displayBooking();
					break;
				case 3:
					customer.updateBooking();
					break;
				case 4:
					customer.cancelBooking();
					break;
				case 5:
					System.out.println("Thank you for using ARS");
					System.out.println("Exiting........");
					System.exit(0);

					break;
				}

			}

		}

		/********************************************************************
		 * 
		 * Admin/executive
		 *
		 * ******************************************************************/

		else if (choice == 2) {

			System.out.println("SELECT THE USER TYPE TO LOGIN : ");
			System.out.println("1. ADMIN LOGIN");
			System.out.println("2. EXECUTIVE LOGIN");
			Byte choice1 = Byte.parseByte(ip.next());

			/********************************************************************
			 * 
			 * Admin functionalities
			 *
			 * ******************************************************************/

			if (choice1 == 1) {

				ip.nextLine();
				System.out.println("Enter username");
				String username = ip.nextLine();
				System.out.println("Enter password");
				String password = ip.nextLine();
				boolean isValid = false;
				try {
					isValid = userService.isValidUser(username, password,
							"Admin");
				} catch (ARSException e) {
					System.out.println("Exception in admin login "
							+ e.getMessage());
				}
				if (isValid) {
					System.out.println("\nWelcome admin :\t" + username);
					while (true) {
						System.out.println("\n\n");
						System.out.println("1--Display Flight Details");
						System.out.println("2--Add Flight");
						System.out.println("3--Update Flight");
						System.out.println("4--delete Flight");
						System.out.println("5--ViewParticular flight");
						System.out.println("6--exit");
						System.out.println("\n\n");

						int choice2 = ip.nextInt();
						ip.nextLine();
						switch (choice2) {

						case 1:

							staff.viewAllFlights();
							
							break;
						case 2:

							staff.addFlight();
							
							break;
						case 3:

							staff.updateFlight();
							
							break;
						case 4:

							staff.deleteFlight();
							
							break;
						case 5:

							staff.viewParticularFlight();
							
							break;
						case 6:
							System.out.println("Thank you for using ARS");
							System.out.println("Exiting........");
							System.exit(0);
						}

					}

				} else {
					System.out.println("Invalid user");
				}

			}

			/********************************************************************
			 * 
			 * executive functionalities
			 *
			 * ******************************************************************/

			else if (choice == 2) {
				ip.nextLine();
				System.out.println("Enter username");
				String username = ip.nextLine();
				System.out.println("Enter password");
				String password = ip.nextLine();
				boolean isValid = false;
				try {
					isValid = userService.isValidUser(username, password,
							"executive");
				} catch (ARSException e) {
					System.err.println("Exception in executive login "
							+ e.getMessage());
				}
				if (isValid) {
					System.out.println("\nWelcome executive :\t" + username);
					while (true) {
						System.out.println("1--view period occupancy");
						System.out.println("2--view overall occupancy");
						System.out.println("3--Exit");
						int choice3 = ip.nextInt();
						switch (choice3) {
						case 1:
							staff.periodOccupancy();
							break;
						case 2:
							staff.overAllOccupancy();
							break;
						case 3:
							System.out.println("Thank you for using ARS");
							System.out.println("Exiting........");
							System.exit(0);
						}
					}

				} else {
					System.out.println("Invalid user");
				}
			}

			ip.close();

		}

	}

}
