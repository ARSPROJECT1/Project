package com.cg.ars.dao;

import com.cg.ars.bean.AirportBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;

public class AirportDaoImpl implements IAirportDao {

	@Override
	public AirportBean fetchDetails(AirportBean airportBean,
			FlightInformationBean flightInformationBean) throws ARSException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AirportBean occupancyDetails(AirportBean airportBean,
			FlightInformationBean flightInformationBean) throws ARSException {
		// TODO Auto-generated method stub
		return null;
	}

}
