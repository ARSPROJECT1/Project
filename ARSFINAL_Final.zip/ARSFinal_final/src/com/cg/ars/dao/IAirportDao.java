/**
 * 
 */
package com.cg.ars.dao;

import com.cg.ars.bean.AirportBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.exception.ARSException;

/**
 * @author CAPG
 *
 */
public interface IAirportDao {

	AirportBean fetchDetails(AirportBean airportBean,FlightInformationBean flightInformationBean)  throws ARSException;

	AirportBean occupancyDetails(AirportBean airportBean,FlightInformationBean flightInformationBean) throws ARSException;

}
