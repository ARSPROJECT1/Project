package com.cg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ars.bean.BookingInformationBean;
import com.cg.ars.bean.FlightInformationBean;
import com.cg.ars.dao.BookingInfoDaoImpl;
import com.cg.ars.dao.IBookingInfoDao;
import com.cg.ars.exception.ARSException;

public class BookingInfoServiceImpl implements IBookingInfoService{

	
	IBookingInfoDao bookingDao=new BookingInfoDaoImpl();

	/**
	 * 
	 */

	@Override
	public String confirmBooking(BookingInformationBean bookingInformationBean,
			FlightInformationBean flightInformationBean) throws ARSException {
		
		return bookingDao.confirmBooking(bookingInformationBean, flightInformationBean);
	}


	@Override
	public List<FlightInformationBean> viewFlights(String Source,
			String destination) throws ARSException {
		
		return bookingDao.viewFlights(Source, destination);
	}


	@Override
	public boolean cancelBooking(String bookingId) throws ARSException {
		
		return bookingDao.cancelBooking(bookingId);
	}


	@Override
	public BookingInformationBean displayBooking(String bookingId)
			throws ARSException {
		
		return bookingDao.displayBooking(bookingId);
	}





	@Override
	public boolean updateSeats(FlightInformationBean flightInformationBean,
			BookingInformationBean bookingInformationBean) throws ARSException {
		
		return bookingDao.updateSeats(flightInformationBean, bookingInformationBean);
	}


	@Override
	public boolean updateBooking(String bookingId, String cust_email)
			throws ARSException {
		
		return bookingDao.updateBooking(bookingId, cust_email);
	}

	
	@Override
	public boolean validateCustomer(BookingInformationBean bean,FlightInformationBean flightInformationBean)
			           throws ARSException
	{
	List<String> validationErrors = new ArrayList<String>();

	//Validating Source City
	if(!(isValidSourceCity(bean.getSourceCity()))) {
	validationErrors.add("\nInvalid sourceCity ! \n");
	}
	//Validating destination City
	if(!(isValidDestinationCity(bean.getDestinationCity()))){
	validationErrors.add("\n Invalid destinationCity! \n");
	}
	//Validating Email Id
	if(!(isValidMail(bean.getCustomerEmail()))){
	validationErrors.add("\n Invalid Email Id \n");
	}
	//Validating Credit Card Info
	if(!(isValidCreditInfo(bean.getCreditCardInformation()))){
	validationErrors.add("\nInvalid Credit Card Info\n" );
	}
	//Validating No. of passenger
	if(!(isValidNoOfPassenger(bean.getNumberOfPassengers()))){
	validationErrors.add("\nNumber of passenger should be  0 to 9\n" );
	}
	
	if(!(isValidFlightNumber(flightInformationBean.getFlightNumber()))){
		validationErrors.add("\nNumber of passenger should be  0 to 9\n" );
		}
	 
	if(!validationErrors.isEmpty())
	{	
	return false;
	}
	
	return true;
	}
	
	
	
	/*******************************************************************************************************
	 - Function Name	:	isValidFlightNumber()
	 - Input Parameters	:   flightNumber
	 - Return Type		:	boolean
	 - Throws		    :   ARSException
	 - Author		    :   ARS Team
	 - Creation Date	:	16/12/2017
	 - Description		:	validating flight Number  
********************************************************************************************************/

	@Override
	public boolean isValidFlightNumber(String flightnumber) throws ARSException {

	boolean isValid = false;

	String pattern = "[\\d]{1,5}";

	Pattern ptn = Pattern.compile(pattern);

	Matcher matcher = ptn.matcher(flightnumber);
	isValid = matcher.matches();

	 
	return isValid;

	}

	
	/*******************************************************************************************************
	 - Function Name	:	isValidSourceCity()
	 - Input Parameters	:   sourceCity
	 - Return Type		:	boolean
	 - Throws		    :   ARSException
	 - Author		    :   ARS Team
	 - Creation Date	:	16/12/2017
	 - Description		:	validating source city  
********************************************************************************************************/

	@Override
	public boolean isValidSourceCity(String sourceCity) throws ARSException {

	boolean isValid = false;

	String pattern = "[a-zA-Z]{4,20}";

	Pattern ptn = Pattern.compile(pattern);

	Matcher matcher = ptn.matcher(sourceCity);
	isValid = matcher.matches();

	 
	return isValid;

	}
	
	
	
	/*******************************************************************************************************
	 - Function Name	:	isValidDestinationCity()
	 - Input Parameters	:   destinationCity
	 - Return Type		:	boolean
	 - Throws		    :   ARSException
	 - Author		    :   ARS Team
	 - Creation Date	:	16/12/2017
	 - Description		:	validating destinationCity 
********************************************************************************************************/

	@Override
	public boolean isValidDestinationCity(String destinationCity) throws ARSException {

	boolean isValid = false;

	String pattern = "[a-zA-Z]{4,20}";

	Pattern ptn = Pattern.compile(pattern);

	Matcher matcher = ptn.matcher(destinationCity);
	isValid = matcher.matches();

	return isValid;

	}

	
	/*******************************************************************************************************
	 - Function Name	:	isValidMail()
	 - Input Parameters	:   emailId
	 - Return Type		:	boolean
	 - Throws		    :   ARSException
	 - Author		    :   ARS Team
	 - Creation Date	:	16/12/2017
	 - Description		:	validating emailId 
********************************************************************************************************/

	@Override
	public boolean isValidMail(String emailId) throws ARSException{
	 
	boolean isValid=false;
	 
	String pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$";

	Pattern ptn=Pattern.compile(pattern);
	 
	Matcher matcher=ptn.matcher(emailId);
	isValid=matcher.matches();
	 
	 
	 
	return isValid;
	 
	}
	
	
	
	/*******************************************************************************************************
	 - Function Name	:	isValidNoOfPassenger()
	 - Input Parameters	:   noOfPassenger
	 - Return Type		:	boolean
	 - Throws		    :   ARSException
	 - Author		    :   ARS Team
	 - Creation Date	:	16/12/2017
	 - Description		:	validating noOfPassenger 
********************************************************************************************************/

	@Override
	public boolean isValidNoOfPassenger(int noOfPassenger) throws ARSException{
	 
	boolean isValid=false;
	 
	String mobile=Integer.toString(noOfPassenger);
	String pattern="[\\d]{1}";

	Pattern ptn=Pattern.compile(pattern);
	 
	Matcher matcher=ptn.matcher(mobile);
	isValid=matcher.matches();
	 
	 
	return isValid;
	 
	}
	
	
	/*******************************************************************************************************
	 - Function Name	:	isValidCreditInfo()
	 - Input Parameters	:   creditInfo
	 - Return Type		:	boolean
	 - Throws		    :   ARSException
	 - Author		    :   ARS Team
	 - Creation Date	:	16/12/2017
	 - Description		:	validating credit card information 
********************************************************************************************************/

	@Override
	public boolean isValidCreditInfo(String creditInfo) throws ARSException {

	boolean isValid = false;

	String pattern = "[\\d]{12,16}";

	Pattern ptn = Pattern.compile(pattern);

	Matcher matcher = ptn.matcher(creditInfo);
	isValid = matcher.matches();

	 
	return isValid;

	}
	

	@Override
	public boolean isValidBookingId(String bookingId) throws ARSException {

	boolean isValid = false;

	String pattern = "[\\d]{1,3}";

	Pattern ptn = Pattern.compile(pattern);

	Matcher matcher = ptn.matcher(bookingId);
	isValid = matcher.matches();

	 
	return isValid;

	}
}
